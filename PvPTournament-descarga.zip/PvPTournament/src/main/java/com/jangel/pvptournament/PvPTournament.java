package com.jangel.pvptournament;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.*;

public final class PvPTournament extends JavaPlugin implements Listener, TabExecutor {
    private static final String MENU = ChatColor.DARK_AQUA + "Kits PvP";
    private static final String EDIT = ChatColor.DARK_GREEN + "Editor de kit: ";
    private final Set<UUID> participants = new LinkedHashSet<>();
    private final Map<UUID,String> editing = new HashMap<>();

    @Override public void onEnable() {
        saveDefaultConfig();
        Objects.requireNonNull(getCommand("pvp")).setExecutor(this);
        Objects.requireNonNull(getCommand("pvp")).setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this,this);
        for (String s : getConfig().getStringList("participants")) try { participants.add(UUID.fromString(s)); } catch (IllegalArgumentException ignored) {}
        getLogger().info("PvPTournament activado");
    }
    @Override public void onDisable() { saveParticipants(); }
    private boolean admin(CommandSender s) {
        if (!(s instanceof Player) || s.isOp() || s.hasPermission("pvptournament.organizer")) return true;
        s.sendMessage(ChatColor.RED + "Necesitas el permiso pvptournament.organizer."); return false;
    }
    private void title(Player p,String a,String b) { p.sendTitle(ChatColor.translateAlternateColorCodes('&',a),ChatColor.translateAlternateColorCodes('&',b),5,40,10); }
    private void allTitle(String a,String b) { Bukkit.getOnlinePlayers().forEach(p -> title(p,a,b)); }
    private ItemStack item(Material m,String name,String... lore) { ItemStack i=new ItemStack(m); ItemMeta meta=i.getItemMeta(); if(meta!=null){meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',name));meta.setLore(Arrays.stream(lore).map(x->ChatColor.translateAlternateColorCodes('&',x)).toList());i.setItemMeta(meta);}return i; }
    private String path(String n) { return "kits."+n.toLowerCase(Locale.ROOT).replace(".","_"); }
    private void saveParticipants(){getConfig().set("participants",participants.stream().map(UUID::toString).toList());saveConfig();}

    @Override public boolean onCommand(CommandSender s,Command c,String label,String[] a){
        if(a.length==0||a[0].equalsIgnoreCase("ayuda")){s.sendMessage(ChatColor.GOLD+"PvPTournament — comandos");s.sendMessage(ChatColor.AQUA+"/pvp participante añadir <jugador>");s.sendMessage(ChatColor.AQUA+"/pvp kit | kit crear|editar|eliminar <nombre>");s.sendMessage(ChatColor.AQUA+"/pvp setspawn1 | setspawn2 | setspawn <lobby|espectador>");s.sendMessage(ChatColor.AQUA+"/pvp iniciar");return true;}
        String r=a[0].toLowerCase(Locale.ROOT);
        if(r.equals("kit")){
            if(a.length==1){if(s instanceof Player p)openMenu(p);else s.sendMessage("Solo dentro del juego.");return true;}
            if(!admin(s))return true;if(!(s instanceof Player p)){s.sendMessage("Comando solo para jugadores.");return true;}
            if(a.length>=3&&a[1].equalsIgnoreCase("crear")){openEditor(p,a[2]);return true;}
            if(a.length>=3&&a[1].equalsIgnoreCase("editar")){if(!getConfig().isConfigurationSection(path(a[2]))){title(p,"&cKit no encontrado","&f/pvp kit crear <nombre>");return true;}openEditor(p,a[2]);return true;}
            if(a.length>=3&&a[1].equalsIgnoreCase("eliminar")){getConfig().set(path(a[2]),null);saveConfig();title(p,"&aKit eliminado","&f"+a[2]);return true;}
            title(p,"&eAdministración de kits","&fcrear, editar o eliminar <nombre>");return true;
        }
        if(r.equals("participante")&&a.length>=3&&a[1].equalsIgnoreCase("añadir")){if(!admin(s))return true;Player t=Bukkit.getPlayerExact(a[2]);if(t==null){s.sendMessage(ChatColor.RED+"El jugador debe estar conectado.");return true;}if(participants.size()>=16&&!participants.contains(t.getUniqueId())){s.sendMessage(ChatColor.RED+"Máximo 16 participantes.");return true;}participants.add(t.getUniqueId());saveParticipants();title(t,"&6¡Estás en el torneo!","&fPrepárate para competir");if(s instanceof Player p)title(p,"&aParticipante añadido","&f"+t.getName());else s.sendMessage("Participante añadido: "+t.getName());return true;}
        if(r.equals("setspawn1")||r.equals("setspawn2")||(r.equals("setspawn")&&a.length>1)){if(!admin(s))return true;if(!(s instanceof Player p)){s.sendMessage("Solo un jugador puede fijar ubicaciones.");return true;}String key=r.equals("setspawn")?a[1].toLowerCase(Locale.ROOT):r;getConfig().set("spawns."+key,p.getLocation());saveConfig();title(p,"&aAparición guardada","&f"+key);return true;}
        if(r.equals("iniciar")){if(!admin(s))return true;long n=participants.stream().map(Bukkit::getPlayer).filter(Objects::nonNull).count();if(n<2){s.sendMessage(ChatColor.RED+"Se necesitan al menos 2 participantes conectados.");return true;}if(n>16){s.sendMessage(ChatColor.RED+"Máximo 16 participantes.");return true;}allTitle("&6¡TORNEO PVP!","&fParticipantes: "+n);s.sendMessage(ChatColor.YELLOW+"Aviso: el cuadro y las rondas automáticas aún no están implementados.");return true;}
        if(s instanceof Player p)title(p,"&cComando desconocido","&fUsa /pvp ayuda");else s.sendMessage("Usa /pvp ayuda");return true;
    }
    private void openMenu(Player p){Inventory inv=Bukkit.createInventory(null,54,MENU);ConfigurationSection sec=getConfig().getConfigurationSection("kits");int slot=0;if(sec!=null)for(String k:sec.getKeys(false)){if(slot>=45)break;inv.setItem(slot++,item(Material.CHEST,"&b"+k,"&7Clic para usar este kit"));}inv.setItem(49,item(Material.BARRIER,"&cCerrar"));p.openInventory(inv);}
    private void openEditor(Player p,String name){Inventory inv=Bukkit.createInventory(null,54,EDIT+name);Object o=getConfig().get(path(name)+".items");if(o instanceof ItemStack[] saved)for(int i=0;i<Math.min(45,saved.length);i++)if(saved[i]!=null)inv.setItem(i,saved[i]);inv.setItem(49,item(Material.EMERALD_BLOCK,"&aGUARDAR KIT","&7Guarda las primeras 45 casillas"));inv.setItem(53,item(Material.BARRIER,"&cCancelar"));editing.put(p.getUniqueId(),name);p.openInventory(inv);title(p,"&2Editor de kits","&f"+name);}
    @EventHandler public void click(InventoryClickEvent e){if(!(e.getWhoClicked() instanceof Player p))return;String t=e.getView().getTitle();if(t.equals(MENU)){e.setCancelled(true);ItemStack i=e.getCurrentItem();if(i==null||!i.hasItemMeta()||i.getType()==Material.BARRIER){p.closeInventory();return;}String name=ChatColor.stripColor(i.getItemMeta().getDisplayName());Object o=getConfig().get(path(name)+".items");if(!(o instanceof ItemStack[] contents)){title(p,"&cKit vacío","&fPide al organizador que lo configure");return;}p.getInventory().clear();for(int n=0;n<Math.min(36,contents.length);n++)if(contents[n]!=null)p.getInventory().setItem(n,contents[n]);p.closeInventory();title(p,"&aKit seleccionado","&f"+name);return;}if(t.startsWith(EDIT)){String name=editing.get(p.getUniqueId());if(name==null){e.setCancelled(true);return;}if(e.getRawSlot()==49){e.setCancelled(true);ItemStack[] contents=new ItemStack[45];for(int n=0;n<45;n++)contents[n]=e.getInventory().getItem(n);getConfig().set(path(name)+".items",contents);saveConfig();editing.remove(p.getUniqueId());p.closeInventory();title(p,"&aKit guardado","&f"+name);}else if(e.getRawSlot()>=45)e.setCancelled(true);}}
    @EventHandler public void drag(InventoryDragEvent e){if(e.getView().getTitle().equals(MENU))e.setCancelled(true);if(e.getView().getTitle().startsWith(EDIT)&&e.getRawSlots().stream().anyMatch(x->x>=45))e.setCancelled(true);}
    @Override public List<String> onTabComplete(CommandSender s,Command c,String alias,String[] a){if(a.length==1)return match(List.of("ayuda","participante","kit","setspawn1","setspawn2","setspawn","iniciar"),a[0]);if(a.length==2&&a[0].equalsIgnoreCase("participante"))return match(List.of("añadir"),a[1]);if(a.length==3&&a[0].equalsIgnoreCase("participante"))return match(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(),a[2]);if(a.length==2&&a[0].equalsIgnoreCase("kit"))return match(List.of("crear","editar","eliminar"),a[1]);if(a.length==3&&a[0].equalsIgnoreCase("kit")){if(a[1].equalsIgnoreCase("crear"))return List.of("<nombre>");ConfigurationSection sec=getConfig().getConfigurationSection("kits");return match(sec==null?List.of():new ArrayList<>(sec.getKeys(false)),a[2]);}if(a.length==2&&a[0].equalsIgnoreCase("setspawn"))return match(List.of("lobby","espectador"),a[1]);return List.of();}
    private List<String> match(List<String> xs,String p){return xs.stream().filter(x->x.toLowerCase(Locale.ROOT).startsWith(p.toLowerCase(Locale.ROOT))).toList();}
}
