# PvPTournament

Proyecto Maven para Paper y Java 25. Incluye comandos con autocompletado, permisos de organizador, registro de participantes (máximo 16), títulos de pantalla, menú gráfico de kits, editor para guardar kits personalizados y puntos de aparición configurables. GitHub Actions intenta compilar y publicar el JAR como artefacto.

## Comandos
- `/pvp ayuda`
- `/pvp participante añadir <jugador>`
- `/pvp kit`
- `/pvp kit crear <nombre>`
- `/pvp kit editar <nombre>`
- `/pvp kit eliminar <nombre>`
- `/pvp setspawn1`, `/pvp setspawn2`, `/pvp setspawn lobby`, `/pvp setspawn espectador`
- `/pvp iniciar`

## Permisos
`pvptournament.organizer` controla comandos administrativos y edición de kits. Los operadores también tienen acceso.

## Compilar
Con JDK 25 y Maven: `mvn clean package`. GitHub Actions ejecuta el mismo proceso al subir cambios.

## Alcance
Esta es una primera versión de la base del plugin. La lógica completa del cuadro de eliminación, selección de 3 de 5 modos, mejor de 3 rondas, emparejamientos y teletransporte automático al iniciar cada duelo aún no está implementada y debe añadirse/probarse antes de usarlo en un torneo real. La dependencia Paper API configurada es `26.2.build.129-stable`; si esa coordenada no existe en el repositorio oficial, la compilación fallará hasta ajustarla a una versión publicada.
