# PvPTournament 2.0

Proyecto fuente para un plugin de torneos PvP de Minecraft, Java 25 y Paper API configurada en `pom.xml`.

## Compilar
Requiere JDK 25 y Maven:
```bash
mvn --batch-mode clean package
```
El JAR queda en `target/PvPTournament-2.0.0.jar`. GitHub Actions compila en cada push/PR y publica el artefacto.

## Comandos
- `/pvp ayuda`
- `/pvp participante añadir <jugador>`
- `/pvp kit` — abrir selector de kits
- `/pvp kit crear <nombre>` — editor gráfico (solo organizador/admin)
- `/pvp kit editar <nombre>`
- `/pvp kit eliminar <nombre>`
- `/pvp arena <nombre> spawn1`
- `/pvp arena <nombre> spawn2`
- `/pvp arena <nombre> eliminar`
- `/pvp spawn lobby|espectador`
- `/pvp modo` — seleccionar tres de los cinco modos configurados
- `/pvp iniciar`
- `/pvp cancelar`
- `/pvp reanudar`
- `/pvp cuadro`
- `/pvp estadisticas`
- `/pvp espectar`

## Permisos
- `pvptournament.admin`: administración total (OP por defecto).
- `pvptournament.organizer`: administrar kits, arenas y torneo (OP por defecto).
- `pvptournament.participant`: reservado para futuras restricciones de acceso.

## Configuración
`src/main/resources/config.yml`: cambia modos, límite, cuenta atrás y comandos de recompensa. Los puntos de spawn se establecen desde el juego.

## Estado de implementación y pruebas
Este es un prototipo funcional de primera iteración, no un lanzamiento de producción. Incluye los comandos, menús de kit/modos, arenas configurables, lógica de emparejamiento secuencial, mejor de tres, estadísticas, anuncios, comandos de recompensa y controles básicos de combate. Antes de usarlo en un torneo real, la compilación y las pruebas de servidor deben validar la versión exacta de Paper API; la coordenada `26.2.build.129-stable` se dejó según lo solicitado y puede requerir ajuste si no existe en el repositorio. La recuperación tras reinicio conserva la lista de participantes y metadatos, pero no reanuda de forma segura una ronda en curso; se recomienda reiniciar el enfrentamiento. Revisar también los eventos de muerte/respawn y el inventario original en el servidor de destino antes de producción.
